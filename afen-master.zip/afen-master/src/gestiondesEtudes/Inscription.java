package gestiondesEtudes;

import java.text.ParseException;

public   interface Inscription {
	public void inscription() throws ParseException ;
	
}
