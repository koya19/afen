module project {
	requires java.desktop;
	requires java.base;
}