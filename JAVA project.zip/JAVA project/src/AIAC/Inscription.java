package AIAC;

public interface Inscription {

}
